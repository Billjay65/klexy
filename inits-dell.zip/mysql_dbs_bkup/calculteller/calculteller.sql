-- MySQL dump 10.13  Distrib 5.7.17, for Win32 (AMD64)
--
-- Host: localhost    Database: calculteller
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


--
-- MyVersion: Specify database to use to avoid error
-- Error 1064 (3D000) at line 22: No database selected
--
USE calculteller;


--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_name` char(35) NOT NULL,
  `country` char(52) NOT NULL,
  `continent` char(52) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=MyISAM AUTO_INCREMENT=233 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1,'Kabul','Afghanistan','Asia'),(2,'Tirana','Albania','Europe'),(3,'Alger','Algeria','Africa'),(4,'Tafuna','American Samoa','Oceania'),(5,'Andorra la Vella','Andorra','Europe'),(6,'Luanda','Angola','Africa'),(7,'South Hill','Anguilla','North America'),(8,'Saint JohnÂ´s','Antigua and Barbuda','North America'),(9,'Buenos Aires','Argentina','South America'),(10,'Yerevan','Armenia','Asia'),(11,'Oranjestad','Aruba','North America'),(12,'Sydney','Australia','Oceania'),(13,'Wien','Austria','Europe'),(14,'Baku','Azerbaijan','Asia'),(15,'Nassau','Bahamas','North America'),(16,'al-Manama','Bahrain','Asia'),(17,'Dhaka','Bangladesh','Asia'),(18,'Bridgetown','Barbados','North America'),(19,'Minsk','Belarus','Europe'),(20,'Antwerpen','Belgium','Europe'),(21,'Belize City','Belize','North America'),(22,'Cotonou','Benin','Africa'),(23,'Saint George','Bermuda','North America'),(24,'Thimphu','Bhutan','Asia'),(25,'Santa Cruz de la Sierra','Bolivia','South America'),(26,'Sarajevo','Bosnia and Herzegovina','Europe'),(27,'Gaborone','Botswana','Africa'),(28,'SÃ£o Paulo','Brazil','South America'),(29,'Bandar Seri Begawan','Brunei','Asia'),(30,'Sofija','Bulgaria','Europe'),(31,'Ouagadougou','Burkina Faso','Africa'),(32,'Bujumbura','Burundi','Africa'),(33,'Phnom Penh','Cambodia','Asia'),(34,'Douala','Cameroon','Africa'),(35,'MontrÃ©al','Canada','North America'),(36,'Praia','Cape Verde','Africa'),(37,'George Town','Cayman Islands','North America'),(38,'Abidjan','CÃ´te dÂ’Ivoire','Africa'),(39,'Bangui','Central African Republic','Africa'),(40,'NÂ´DjamÃ©na','Chad','Africa'),(41,'Santiago de Chile','Chile','South America'),(42,'Shanghai','China','Asia'),(43,'Flying Fish Cove','Christmas Island','Oceania'),(44,'Bantam','Cocos (Keeling) Islands','Oceania'),(45,'SantafÃ© de BogotÃ¡','Colombia','South America'),(46,'Moroni','Comoros','Africa'),(47,'Brazzaville','Congo','Africa'),(48,'Kinshasa','Congo, The Democratic Republic of the','Africa'),(49,'Avarua','Cook Islands','Oceania'),(50,'San JosÃ©','Costa Rica','North America'),(51,'Zagreb','Croatia','Europe'),(52,'La Habana','Cuba','North America'),(53,'Nicosia','Cyprus','Asia'),(54,'Praha','Czech Republic','Europe'),(55,'KÃ¸benhavn','Denmark','Europe'),(56,'Djibouti','Djibouti','Africa'),(57,'Roseau','Dominica','North America'),(58,'Santo Domingo de GuzmÃ¡n','Dominican Republic','North America'),(59,'Dili','East Timor','Asia'),(60,'Guayaquil','Ecuador','South America'),(61,'Cairo','Egypt','Africa'),(62,'San Salvador','El Salvador','North America'),(63,'Malabo','Equatorial Guinea','Africa'),(64,'Asmara','Eritrea','Africa'),(65,'Tallinn','Estonia','Europe'),(66,'Addis Abeba','Ethiopia','Africa'),(67,'Stanley','Falkland Islands','South America'),(68,'TÃ³rshavn','Faroe Islands','Europe'),(69,'Suva','Fiji Islands','Oceania'),(70,'Helsinki [Helsingfors]','Finland','Europe'),(71,'Paris','France','Europe'),(72,'Cayenne','French Guiana','South America'),(73,'Faaa','French Polynesia','Oceania'),(74,'Libreville','Gabon','Africa'),(75,'Serekunda','Gambia','Africa'),(76,'Tbilisi','Georgia','Asia'),(77,'Berlin','Germany','Europe'),(78,'Accra','Ghana','Africa'),(79,'Gibraltar','Gibraltar','Europe'),(80,'Athenai','Greece','Europe'),(81,'Nuuk','Greenland','North America'),(82,'Saint GeorgeÂ´s','Grenada','North America'),(83,'Les Abymes','Guadeloupe','North America'),(84,'Tamuning','Guam','Oceania'),(85,'Ciudad de Guatemala','Guatemala','North America'),(86,'Conakry','Guinea','Africa'),(87,'Bissau','Guinea-Bissau','Africa'),(88,'Georgetown','Guyana','South America'),(89,'Port-au-Prince','Haiti','North America'),(90,'CittÃ  del Vaticano','Holy See (Vatican City State)','Europe'),(91,'Tegucigalpa','Honduras','North America'),(92,'Kowloon and New Kowloon','Hong Kong','Asia'),(93,'Budapest','Hungary','Europe'),(94,'ReykjavÃ­k','Iceland','Europe'),(95,'Mumbai (Bombay)','India','Asia'),(96,'Jakarta','Indonesia','Asia'),(97,'Teheran','Iran','Asia'),(98,'Baghdad','Iraq','Asia'),(99,'Dublin','Ireland','Europe'),(100,'Jerusalem','Israel','Asia'),(101,'Roma','Italy','Europe'),(102,'Spanish Town','Jamaica','North America'),(103,'Tokyo','Japan','Asia'),(104,'Amman','Jordan','Asia'),(105,'Almaty','Kazakstan','Asia'),(106,'Nairobi','Kenya','Africa'),(107,'Bikenibeu','Kiribati','Oceania'),(108,'al-Salimiya','Kuwait','Asia'),(109,'Bishkek','Kyrgyzstan','Asia'),(110,'Vientiane','Laos','Asia'),(111,'Riga','Latvia','Europe'),(112,'Beirut','Lebanon','Asia'),(113,'Maseru','Lesotho','Africa'),(114,'Monrovia','Liberia','Africa'),(115,'Tripoli','Libyan Arab Jamahiriya','Africa'),(116,'Schaan','Liechtenstein','Europe'),(117,'Vilnius','Lithuania','Europe'),(118,'Luxembourg [Luxemburg/LÃ«tzebuerg]','Luxembourg','Europe'),(119,'Macao','Macao','Asia'),(120,'Skopje','Macedonia','Europe'),(121,'Antananarivo','Madagascar','Africa'),(122,'Blantyre','Malawi','Africa'),(123,'Kuala Lumpur','Malaysia','Asia'),(124,'Male','Maldives','Asia'),(125,'Bamako','Mali','Africa'),(126,'Birkirkara','Malta','Europe'),(127,'Dalap-Uliga-Darrit','Marshall Islands','Oceania'),(128,'Fort-de-France','Martinique','North America'),(129,'Nouakchott','Mauritania','Africa'),(130,'Port-Louis','Mauritius','Africa'),(131,'Mamoutzou','Mayotte','Africa'),(132,'Ciudad de MÃ©xico','Mexico','North America'),(133,'Weno','Micronesia, Federated States of','Oceania'),(134,'Chisinau','Moldova','Europe'),(135,'Monte-Carlo','Monaco','Europe'),(136,'Ulan Bator','Mongolia','Asia'),(137,'Plymouth','Montserrat','North America'),(138,'Casablanca','Morocco','Africa'),(139,'Maputo','Mozambique','Africa'),(140,'Rangoon (Yangon)','Myanmar','Asia'),(141,'Windhoek','Namibia','Africa'),(142,'Yangor','Nauru','Oceania'),(143,'Kathmandu','Nepal','Asia'),(144,'Amsterdam','Netherlands','Europe'),(145,'Willemstad','Netherlands Antilles','North America'),(146,'NoumÃ©a','New Caledonia','Oceania'),(147,'Auckland','New Zealand','Oceania'),(148,'Managua','Nicaragua','North America'),(149,'Niamey','Niger','Africa'),(150,'Lagos','Nigeria','Africa'),(151,'Alofi','Niue','Oceania'),(152,'Kingston','Norfolk Island','Oceania'),(153,'Pyongyang','North Korea','Asia'),(154,'Garapan','Northern Mariana Islands','Oceania'),(155,'Oslo','Norway','Europe'),(156,'al-Sib','Oman','Asia'),(157,'Karachi','Pakistan','Asia'),(158,'Koror','Palau','Oceania'),(159,'Gaza','Palestine','Asia'),(160,'Ciudad de PanamÃ¡','Panama','North America'),(161,'Port Moresby','Papua New Guinea','Oceania'),(162,'AsunciÃ³n','Paraguay','South America'),(163,'Lima','Peru','South America'),(164,'Quezon','Philippines','Asia'),(165,'Adamstown','Pitcairn','Oceania'),(166,'Warszawa','Poland','Europe'),(167,'Lisboa','Portugal','Europe'),(168,'San Juan','Puerto Rico','North America'),(169,'Doha','Qatar','Asia'),(170,'Saint-Denis','RÃ©union','Africa'),(171,'Bucuresti','Romania','Europe'),(172,'Moscow','Russian Federation','Europe'),(173,'Kigali','Rwanda','Africa'),(174,'Jamestown','Saint Helena','Africa'),(175,'Basseterre','Saint Kitts and Nevis','North America'),(176,'Castries','Saint Lucia','North America'),(177,'Saint-Pierre','Saint Pierre and Miquelon','North America'),(178,'Kingstown','Saint Vincent and the Grenadines','North America'),(179,'Apia','Samoa','Oceania'),(180,'Serravalle','San Marino','Europe'),(181,'SÃ£o TomÃ©','Sao Tome and Principe','Africa'),(182,'Riyadh','Saudi Arabia','Asia'),(183,'Pikine','Senegal','Africa'),(184,'Victoria','Seychelles','Africa'),(185,'Freetown','Sierra Leone','Africa'),(186,'Singapore','Singapore','Asia'),(187,'Bratislava','Slovakia','Europe'),(188,'Ljubljana','Slovenia','Europe'),(189,'Honiara','Solomon Islands','Oceania'),(190,'Mogadishu','Somalia','Africa'),(191,'Cape Town','South Africa','Africa'),(192,'Seoul','South Korea','Asia'),(193,'Madrid','Spain','Europe'),(194,'Colombo','Sri Lanka','Asia'),(195,'Omdurman','Sudan','Africa'),(196,'Paramaribo','Suriname','South America'),(197,'Longyearbyen','Svalbard and Jan Mayen','Europe'),(198,'Mbabane','Swaziland','Africa'),(199,'Stockholm','Sweden','Europe'),(200,'ZÃ¼rich','Switzerland','Europe'),(201,'Damascus','Syria','Asia'),(202,'Taipei','Taiwan','Asia'),(203,'Dushanbe','Tajikistan','Asia'),(204,'Dar es Salaam','Tanzania','Africa'),(205,'Bangkok','Thailand','Asia'),(206,'LomÃ©','Togo','Africa'),(207,'Fakaofo','Tokelau','Oceania'),(208,'NukuÂ´alofa','Tonga','Oceania'),(209,'Chaguanas','Trinidad and Tobago','North America'),(210,'Tunis','Tunisia','Africa'),(211,'Istanbul','Turkey','Asia'),(212,'Ashgabat','Turkmenistan','Asia'),(213,'Cockburn Town','Turks and Caicos Islands','North America'),(214,'Funafuti','Tuvalu','Oceania'),(215,'Kampala','Uganda','Africa'),(216,'Kyiv','Ukraine','Europe'),(217,'Dubai','United Arab Emirates','Asia'),(218,'London','United Kingdom','Europe'),(219,'New York','United States','North America'),(220,'Montevideo','Uruguay','South America'),(221,'Toskent','Uzbekistan','Asia'),(222,'Port-Vila','Vanuatu','Oceania'),(223,'Caracas','Venezuela','South America'),(224,'Ho Chi Minh City','Vietnam','Asia'),(225,'Road Town','Virgin Islands, British','North America'),(226,'Charlotte Amalie','Virgin Islands, U.S.','North America'),(227,'Mata-Utu','Wallis and Futuna','Oceania'),(228,'El-AaiÃºn','Western Sahara','Africa'),(229,'Sanaa','Yemen','Asia'),(230,'Beograd','Yugoslavia','Europe'),(231,'Lusaka','Zambia','Africa'),(232,'Harare','Zimbabwe','Africa');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domain`
--

DROP TABLE IF EXISTS `domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `domain` (
  `domain_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`domain_id`),
  UNIQUE KEY `name` (`name`),
  FULLTEXT KEY `idx_ft_domain_name_description` (`name`,`description`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domain`
--

LOCK TABLES `domain` WRITE;
/*!40000 ALTER TABLE `domain` DISABLE KEYS */;
INSERT INTO `domain` VALUES (1,'Balance','Calculates the balance of a buyer or seller','balance.png'),(2,'Bet','Calculates bet wins and losses','bet.png'),(3,'Proportion','Calculates simple proportion and predicts the future','proportion.png'),(4,'Time','Calculates time of different time zones of the globe','time.png'),(5,'Business','Calculates profits and losses to investment in business','business.png'),(6,'Bank','Calculates interest, loans and dividents.','bank.png'),(7,'School','Calculates averages, coefficients and positions','school.png'),(8,'Measurements','Calculates dimensions and quantities of objects like the circumference and area of a circle.','measurements.png'),(9,'Maths','Calculates differentials, integrals and other complex maths functions.','maths.png'),(10,'Age','Calculates and reveals your age, birthday, and other important information of your lifetime.','age.png'),(12,'Electricity','Calculates electric bills of tenants, landlords','electricity.png');
/*!40000 ALTER TABLE `domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domain_tab`
--

DROP TABLE IF EXISTS `domain_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `domain_tab` (
  `tab_id` int(11) NOT NULL AUTO_INCREMENT,
  `domain_id` int(11) NOT NULL,
  `tab_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`tab_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domain_tab`
--

LOCK TABLES `domain_tab` WRITE;
/*!40000 ALTER TABLE `domain_tab` DISABLE KEYS */;
INSERT INTO `domain_tab` VALUES (1,1,'Single Item'),(2,1,'Shopping List'),(3,2,'Parifoot'),(4,2,'Fair_Play'),(5,7,'Average'),(6,7,'Score'),(7,3,'Simple'),(8,5,'Investment'),(9,5,'Shop'),(10,6,'Loan'),(11,6,'Savings'),(12,9,'Differentials'),(13,10,'Age'),(14,10,'Birthday'),(15,8,'Circle'),(16,8,'Rectangle'),(18,12,'Bill Tenant');
/*!40000 ALTER TABLE `domain_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domain_unit`
--

DROP TABLE IF EXISTS `domain_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `domain_unit` (
  `domain_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  PRIMARY KEY (`domain_id`,`unit_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domain_unit`
--

LOCK TABLES `domain_unit` WRITE;
/*!40000 ALTER TABLE `domain_unit` DISABLE KEYS */;
INSERT INTO `domain_unit` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20),(1,21),(1,22),(1,23),(1,24),(1,25),(1,26),(1,27),(1,29),(1,30),(2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(2,9),(2,10),(2,11),(2,12),(2,13),(2,14),(2,15),(2,16),(2,17),(2,18),(2,19),(2,20),(2,21),(2,22),(2,23),(2,24),(2,25),(2,26),(2,27),(2,29),(2,30),(3,1),(3,2),(3,3),(3,4),(3,5),(3,6),(3,7),(3,8),(3,9),(3,10),(3,11),(3,12),(3,13),(3,14),(3,15),(3,16),(3,17),(3,18),(3,19),(3,20),(3,21),(3,22),(3,23),(3,24),(3,25),(3,26),(3,27),(3,29),(3,30),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(4,7),(4,8),(4,9),(4,10),(4,11),(4,12),(4,13),(4,14),(4,15),(4,16),(4,17),(4,18),(4,19),(4,20),(4,21),(4,22),(4,23),(4,24),(4,25),(4,26),(4,27),(4,29),(4,30),(5,1),(5,2),(5,3),(5,4),(5,5),(5,6),(5,7),(5,8),(5,9),(5,10),(5,11),(5,12),(5,13),(5,14),(5,15),(5,16),(5,17),(5,18),(5,19),(5,20),(5,21),(5,22),(5,23),(5,24),(5,25),(5,26),(5,27),(5,29),(5,30),(6,1),(6,2),(6,3),(6,4),(6,5),(6,6),(6,7),(6,8),(6,9),(6,10),(6,11),(6,12),(6,13),(6,14),(6,15),(6,16),(6,17),(6,18),(6,19),(6,20),(6,21),(6,22),(6,23),(6,24),(6,25),(6,26),(6,27),(6,29),(6,30),(7,1),(7,2),(7,3),(7,4),(7,5),(7,6),(7,7),(7,8),(7,9),(7,10),(7,11),(7,12),(7,13),(7,14),(7,15),(7,16),(7,17),(7,18),(7,19),(7,20),(7,21),(7,22),(7,23),(7,24),(7,25),(7,26),(7,27),(7,29),(7,30),(8,1),(8,2),(8,3),(8,4),(8,5),(8,6),(8,7),(8,8),(8,9),(8,10),(8,11),(8,12),(8,13),(8,14),(8,15),(8,16),(8,17),(8,18),(8,19),(8,20),(8,21),(8,22),(8,23),(8,24),(8,25),(8,26),(8,27),(8,29),(8,30),(9,1),(9,2),(9,3),(9,4),(9,5),(9,6),(9,7),(9,8),(9,9),(9,10),(9,11),(9,12),(9,13),(9,14),(9,15),(9,16),(9,17),(9,18),(9,19),(9,20),(9,21),(9,22),(9,23),(9,24),(9,25),(9,26),(9,27),(9,29),(9,30),(10,1),(10,2),(10,3),(10,4),(10,5),(10,6),(10,7),(10,8),(10,9),(10,10),(10,11),(10,12),(10,13),(10,14),(10,15),(10,16),(10,17),(10,18),(10,19),(10,20),(10,21),(10,22),(10,23),(10,24),(10,25),(10,26),(10,27),(10,29),(10,30),(12,1),(12,2),(12,3),(12,4),(12,5),(12,6),(12,7),(12,8),(12,9),(12,10),(12,11),(12,12),(12,13),(12,14),(12,15),(12,16),(12,17),(12,18),(12,19),(12,20),(12,21),(12,22),(12,23),(12,24),(12,25),(12,26),(12,27),(12,29),(12,30);
/*!40000 ALTER TABLE `domain_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `mailid` int(11) NOT NULL,
  `path` char(100) NOT NULL,
  `mimetype` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (6,'chart.gif','image/gif'),(6,'admin_logo.PNG','image/png'),(7,'chart.gif','image/gif'),(7,'admin_logo.PNG','image/png'),(8,'chart.gif','image/gif'),(8,'admin_logo.PNG','image/png');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lists`
--

DROP TABLE IF EXISTS `lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `listname` char(20) NOT NULL,
  `blurb` varchar(255) DEFAULT NULL,
  `language` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`listid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lists`
--

LOCK TABLES `lists` WRITE;
/*!40000 ALTER TABLE `lists` DISABLE KEYS */;
INSERT INTO `lists` VALUES (1,'CalculTELLER News','CalculTELLER Newsletter; calculteller updates and improvements; new opportunities for calculteller workers, investors and users; Calculteller new procedures and methods; new deals and partners. ',1),(2,'CalculTELLER News2','CalculTELLER Newsletter; calculteller updates and improvements; new opportunities for calculteller workers, ',1),(3,'CalculTELLER Info','Mis a jours, nouvautes et opportunite.',2);
/*!40000 ALTER TABLE `lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail`
--

DROP TABLE IF EXISTS `mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail` (
  `mailid` int(11) NOT NULL AUTO_INCREMENT,
  `email` char(100) NOT NULL,
  `subject` char(100) NOT NULL,
  `listid` int(11) NOT NULL,
  `status` char(10) NOT NULL,
  `sent` datetime DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mailid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail`
--

LOCK TABLES `mail` WRITE;
/*!40000 ALTER TABLE `mail` DISABLE KEYS */;
INSERT INTO `mail` VALUES (1,'admin@localhost','Welcome to CalculTELLER',3,'STORED',NULL,'2018-03-13 17:36:26'),(2,'admin@localhost','Welcome to CalculTELLER',3,'STORED',NULL,'2018-03-13 17:38:29'),(3,'admin@localhost','Welcome to CalculTELLER',3,'STORED',NULL,'2018-03-13 17:39:08'),(4,'admin@localhost','Welcome to CalculTELLER',3,'STORED',NULL,'2018-03-13 17:42:34'),(5,'admin@localhost','Welcome to CalculTELLER',3,'STORED',NULL,'2018-03-13 17:43:02'),(6,'admin@localhost','Welcome to CalculTELLER',3,'STORED',NULL,'2018-03-13 17:44:05'),(7,'admin@localhost','Welcome to CalculTELLER',3,'STORED',NULL,'2018-03-14 05:07:05'),(8,'admin@localhost','Welcome to CalculTELLER',3,'STORED',NULL,'2018-03-14 05:07:51');
/*!40000 ALTER TABLE `mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_lists`
--

DROP TABLE IF EXISTS `sub_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_lists` (
  `email` char(100) NOT NULL,
  `listid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_lists`
--

LOCK TABLES `sub_lists` WRITE;
/*!40000 ALTER TABLE `sub_lists` DISABLE KEYS */;
INSERT INTO `sub_lists` VALUES ('japhet@yahoo.com',2),('japhet@yahoo.com',1);
/*!40000 ALTER TABLE `sub_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscribers`
--

DROP TABLE IF EXISTS `subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscribers` (
  `email` char(100) NOT NULL,
  `realname` char(100) NOT NULL,
  `mimetype` char(1) NOT NULL,
  `password` char(40) NOT NULL,
  `admin` tinyint(4) NOT NULL,
  `language` tinyint(4) NOT NULL DEFAULT '1',
  `code` int(7) NOT NULL,
  `verified` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscribers`
--

LOCK TABLES `subscribers` WRITE;
/*!40000 ALTER TABLE `subscribers` DISABLE KEYS */;
INSERT INTO `subscribers` VALUES ('admin@localhost','Administrative User','H','d033e22ae348aeb5660fc2140aec35850c4da997',1,1,0,0),('amzi@yahoo.com','','','ac4e6cddb74d5ffe880c9372cb96209729ba4ddd',0,1,3962646,0),('amzy1@yahoo.com','Amzi','H','b1022082fcb3300c1bbac86b894db7915e2ca320',0,1,4966614,0),('amzy2@yahoo.com','Amzi','H','0d4c947411fa0d7ad4fc03064d3eb5ca289fae00',0,1,4249268,0),('amzy@yahoo.com','Amzi','H','b1022082fcb3300c1bbac86b894db7915e2ca320',0,1,3715271,0),('james@yahoo.com','James Brown','H','a6767384bc950e4b1834c98fdf1906887618edd1',0,1,3900879,0),('japhet@yahoo.com','jay','H','938c7beadf96863ea61578062c546154768855f4',0,1,4507447,1),('japhetsikeh@yahoo.com','12222','H','c64b583633635468cc2fca44cb46a4a770f3c93d',0,1,3346114,1);
/*!40000 ALTER TABLE `subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit`
--

DROP TABLE IF EXISTS `unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `abbrevation` varchar(50) NOT NULL,
  `unit_name` varchar(50) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit`
--

LOCK TABLES `unit` WRITE;
/*!40000 ALTER TABLE `unit` DISABLE KEYS */;
INSERT INTO `unit` VALUES (1,'unit(s)','unit(s)'),(2,'mm','millimeter(s)'),(3,'cm','centimeter(s)'),(4,'m','meter(s)'),(5,'km','kilometers(s)'),(6,'s','second(s)'),(7,'mn','minute(s)'),(8,'h','hour(s)'),(9,'dy','day(s)'),(10,'mth','month(s)'),(11,'yr','year(s)'),(12,'wk','week(s)'),(13,'deg','degree(s)'),(14,'USD','US Dolar(s)'),(15,'XAF','Francs CFA'),(16,'m2','square meters'),(17,'km2','square kilometers'),(18,'ha','hectare(s)'),(19,'L','liter(s)'),(20,'%','percent'),(21,'person(s)','person(s)'),(22,'m3','cubic meter(s)'),(23,'cm3','cubic centimeter(s)'),(24,'NGN','Naira'),(25,'GBP','Pound(s)'),(26,'EUR','Euro(s)'),(27,'INR','Indian Rupee'),(29,'kg','Kilogram(s)'),(30,'g','gram(s)');
/*!40000 ALTER TABLE `unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `country` varchar(100) NOT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `lvisit` datetime DEFAULT NULL,
  PRIMARY KEY (`username`),
  UNIQUE KEY `idx_user_email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('Sikeh Japhet','jay','a94d681bddb79479df3abbdc43e96c6d3993db5f','jay@yahoo.com','fot','Dschang','West','Cameroon','651826527','2023-02-24 12:46:12');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_data`
--

DROP TABLE IF EXISTS `user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_data` (
  `data_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `data_value` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `saved` datetime NOT NULL,
  PRIMARY KEY (`data_id`),
  KEY `idx_user_data_username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_data`
--

LOCK TABLES `user_data` WRITE;
/*!40000 ALTER TABLE `user_data` DISABLE KEYS */;
INSERT INTO `user_data` VALUES (1,'jay','BALANCE: 0 FRS','If AMOUNT equals  FRS and item COST equals  FRS therefore BALANCE equals 0 FRS.','2017-10-24 00:54:38'),(2,'jay','Balance: 0','If AMOUNT equals  FRS and item COST equals  FRS therefore BALANCE equals 0 FRS.   \r\n\r\n- Hencel\'s Change \r\n- Pay on the 11/24/2017','2018-05-17 11:23:00'),(6,'pencil','LOAN: 2680000 FRS','If AMOUNT equals 2500000 FRS and INTEREST RATE  1.2 % PER YEAR/MONTH and LOAN DURATION is 6 THEREFORE TOTAL LOAN EQUALS  2680000 YEAR(S)/MONTH(S)) FRS.','2017-10-27 17:44:22'),(7,'cbreezy','BALANCE: 343000 FRS','If AMOUNT equals 1000000 FRS and item COST equals 657000 FRS therefore BALANCE equals 343000 FRS.','2017-10-27 18:54:10'),(8,'cbreezy','LOAN: 1200000 FRS','If AMOUNT equals 1000000 FRS and INTEREST RATE  20 % PER YEAR/MONTH and LOAN DURATION is 1 THEREFORE TOTAL LOAN EQUALS  1200000 YEAR(S)/MONTH(S)) FRS.','2017-10-27 19:16:32'),(9,'jay','','','2018-05-17 11:02:51'),(13,'jay','','','2018-05-17 17:18:52'),(14,'jay','BALANCE: 0 FRS','If AMOUNT equals  FRS and item COST equals  FRS therefore BALANCE equals 0 FRS.','2018-05-18 10:25:12'),(29,'jay','ELECTRIC BILL: 287.6876 XAF','If Date: 2023-02-24   Current Reading: 23.876876   Previous Reading: 21   Unit Cost: 100  Hence Units Equals: 2.876876  Hence ELECTRIC BILL equals: 287.6876 ','2023-02-24 13:17:58');
/*!40000 ALTER TABLE `user_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-30 18:24:24
